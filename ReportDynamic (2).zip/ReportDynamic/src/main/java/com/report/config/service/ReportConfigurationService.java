package com.report.config.service;


import java.util.*;

import com.report.config.dto.ReportConfigurationDTO;
import com.report.config.dto.ReportDataDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.hibernate.query.sql.internal.NativeQueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.report.config.entity.ReportConfiguration;
import com.report.config.entity.ColumnConfiguration;
import com.report.config.entity.HedgeData;
import com.report.config.repository.ColumnConfigurationRepository;
import com.report.config.repository.ReportConfigurationRepository;

@Service
public class ReportConfigurationService {

    @Autowired
    private ReportConfigurationRepository reportConfigurationRepository;

    @Autowired
    private ColumnConfigurationRepository columnConfigurationRepository;

    @Autowired //@PersistentContext
    private EntityManager entityManager;


    // to fetch all the reports along with columns
    public List<ReportConfiguration> fetchReportList() {
        return (List<ReportConfiguration>) reportConfigurationRepository.findAll();
    }

    // to fetch all the columns
    public List<ColumnConfiguration> fetchColumnList() {
        return (List<ColumnConfiguration>) columnConfigurationRepository.findAll();
    }

    // to fetch individual report
    public ResponseEntity<ReportConfiguration> fetchReportWithColumn(Long reportId) {
        Optional<ReportConfiguration> reportConfiguration = reportConfigurationRepository.findById(reportId);
        if (reportConfiguration.isPresent()) {
            return new ResponseEntity<>(reportConfiguration.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(new ReportConfiguration(), HttpStatus.NOT_FOUND);

    }

    public ResponseEntity<ReportConfigurationDTO> fetchReportWithData(Long reportId) {
        Optional<ReportConfiguration> reportConfiguration = reportConfigurationRepository.findById(reportId);
        //ReportConfigurationDTO reportConfigurationDTO = new ReportConfigurationDTO();
        if (reportConfiguration.isPresent()) {
           return fetchData(reportConfiguration.get());
        }
        return new ResponseEntity<>(new ReportConfigurationDTO(), HttpStatus.NOT_FOUND);
    }

    public ResponseEntity<ReportConfigurationDTO> fetchData(ReportConfiguration reportConfiguration) {

        // ModelMapper modelMapper = new ModelMapper();
        // ReportConfigurationDTO reportConfigurationDTO = modelMapper.map(reportConfiguration.get(), ReportConfigurationDTO.class);
        StringBuilder builder = new StringBuilder();
        ReportConfigurationDTO reportConfigurationDTO = new ReportConfigurationDTO();
        builder.append("SELECT ID, ");
        List<ColumnConfiguration> list = reportConfiguration.getColumns();
        for(int i=0;i<list.size();i++){
            if(i!=list.size()-1)
                builder.append(list.get(i).getColumnName()+", ");
            else
                builder.append(list.get(i).getColumnName()+" FROM HEDGE_DATA");
        }
        // Create query
        String nativeQuery = builder.toString();
        Query query = entityManager.createNativeQuery(nativeQuery);
        NativeQueryImpl nativeQueryImpl = (NativeQueryImpl) query;
        nativeQueryImpl.setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
        List<Map< String, Object >> listMap = query.getResultList();

        reportConfigurationDTO.setReportId(reportConfiguration.getReportId());
        reportConfigurationDTO.setReportName(reportConfiguration.getReportName());
        reportConfigurationDTO.setReportType(reportConfiguration.getReportType());
        reportConfigurationDTO.setColumnConfigs(listMap);

        //  Query query = entityManager.createNativeQuery(nativeQuery, ReportDataDTO.class);
        return new ResponseEntity<>(reportConfigurationDTO, HttpStatus.OK);
    }

    public ReportConfiguration saveReport(ReportConfiguration report) {
        return reportConfigurationRepository.save(report);
    }




    /*for (Map< String, Object > map: listMap) {
            map.put("REPORT_ID",reportConfiguration.getReportId());
            map.put("REPORT_NAME",reportConfiguration.getReportName());
            map.put("REPORT_TYPE",reportConfiguration.getReportType());
            System.out.println("==============after request ==" + map);
        }*/
}
