package com.report.config.controller;


import java.util.List;
import java.util.Map;

import com.report.config.dto.ReportConfigurationDTO;
import com.report.config.entity.HedgeData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.report.config.entity.ReportConfiguration;
import com.report.config.entity.ColumnConfiguration;
import com.report.config.service.ReportConfigurationService;

    @RestController
    public class ReportConfigurationController {

        @Autowired
        private ReportConfigurationService reportConfigurationService;

        @GetMapping("/reports")
        public List<ReportConfiguration> fetchReportList()
        {
            return reportConfigurationService.fetchReportList();
        }

        @GetMapping("/columns")
        public List<ColumnConfiguration> fetchColumnList()
        {
            return reportConfigurationService.fetchColumnList();
        }

        @GetMapping("/reports/columns/{id}")
        public ResponseEntity<ReportConfiguration> fetchReportWithColumn(@PathVariable("id") Long reportId)
        {
            return reportConfigurationService.fetchReportWithColumn(reportId);
        }

        @GetMapping("/reports/{id}")
        public ResponseEntity<ReportConfigurationDTO> fetchReportWithData(@PathVariable("id") Long reportId)
        {
            return reportConfigurationService.fetchReportWithData(reportId);
        }

        @PostMapping("/reports")
        public ReportConfiguration saveReport(@RequestBody ReportConfiguration reportConfiguration)
        {
            return reportConfigurationService.saveReport(reportConfiguration);
        }
    }

