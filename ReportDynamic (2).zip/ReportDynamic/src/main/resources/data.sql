insert into REPORT_CONFIGURATION (report_name,report_type) values 
('creditBill', 'pdf'),
('BankStatement','csv'),
('Finance', 'xls');

insert into COLUMN_CONFIGURATION (column_id,column_name,color,data_length,font_style,font_size) values
('1', 'FUND_NAME','Red','10','Arial','8'),
('2', 'MANAGER','Black','15','Calibri','7'),
('3', 'MANAGER_CONTACT','Blue','20','Sans','8'),
('4', 'STRATEGY','Purple','10','Italic','8'),
('5', 'GEO_FOCUS','Pink','15','Micro','7'),
('6', 'FUND_INCEPTION','Yellow','20','Bold','8'),
('7', 'MANAGER_FOUNDED','Red','20','MicroSans','7');

insert into HEDGE_DATA (ID,FUND_NAME,MANAGER,MANAGER_CONTACT,STRATEGY,GEO_FOCUS,
FUND_INCEPTION,MANAGER_FOUNDED) values
('1', 'HEDGE','Asset Management','Jack F','Multi-Strategy','Global','1990','1989'),
('2', 'PPF','Savings Management','Denver S','Single-Strategy','Global','1995','1989'),
('3', 'EPF','Savings Management','Rick J','Multi-Strategy','Global','1990','1989'),
('4', 'ELSS','Asset Management','Denver H','Multi-Strategy','Global','1990','1989'),
('5', 'ICICI','Prudential Fund','Carl J','Multi-Strategy','Global','1990','1989'),
('6', 'HDFC','Asset Management','Peter H','Multi-Strategy','Global','1990','1989'),
('7', 'SBI','Asset Management','Mike T','Multi-Strategy','Global','1990','1989'),
('8', 'QUANT','Mutual Fund','Shane W','Multi-Strategy','Global','1990','1989');

insert into BRIDGE_CONFIGURATION (report_id,column_ID) values
('1', '1'),
('1','2'),
('1','4'),
('1', '5'),
('2', '1'),
('2','6'),
('2', '7'),
('3', '1'),
('3','3'),
('3', '5'),
('3', '6');

