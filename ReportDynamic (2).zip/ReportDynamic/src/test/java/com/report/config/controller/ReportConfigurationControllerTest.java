package com.report.config.controller;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ReportConfigurationControllerTest {

    @Test
    void fetchReportList() {
    }

    @Test
    void fetchColumnList() {
    }

    @Test
    void fetchReportWithColumn() {
    }

    @Test
    void fetchReportWithData() {
    }
}